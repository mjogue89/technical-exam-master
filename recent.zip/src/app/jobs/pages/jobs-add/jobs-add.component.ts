import { Component, Input, OnInit } from "@angular/core";
import { faPlus } from "@fortawesome/free-solid-svg-icons";
import { Router } from "@angular/router";

import { Job } from "../../../shared/models/jobs";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";
import * as actions from "../../state/jobs-add.actions";
import * as fromJob from "../../state/jobs-add.reducer";
import { JobsService } from "../../../jobs.service";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

@Component({
  selector: "app-jobs-add",
  templateUrl: "./jobs-add.component.html",
  styleUrls: ["./jobs-add.component.scss"]
})
export class JobsAddComponent implements OnInit {
  // @ts-ignore
  jobs: Observable<any>;
  add = faPlus;
  jobPosition: any;
  companyName: any;
  status: any;
  company: any = [];
  addForm: FormGroup;

  constructor(
    private store: Store<fromJob.JobState>,
    private router: Router,
    private main: JobsService,
    private fb: FormBuilder
  ) {
    this.addForm = this.fb.group({
      company: ["", Validators.required],
      type: ["", Validators.required],
      title: ["", Validators.required],
      id: [new Date().getTime()],
      date: [new Date().toLocaleDateString("en-US")]
    });
  }

  ngOnInit(): void {
    this.getCompanyNames();
  }

  getCompanyNames() {
    this.main.getCompanies().subscribe((value: any) => {
      this.company = value || [];
    });
  }

  addPost() {
    if (this.addForm.valid) {
      this.main.addPosting(this.addForm.getRawValue()).then((resolve: any) => {
        this.addForm.reset();
      });
    }
  }

  back() {
    this.router.navigate(["jobs"]);
  }

  postJob() {
    console.log(this.jobPosition);
    console.log(this.companyName);
  }
}
