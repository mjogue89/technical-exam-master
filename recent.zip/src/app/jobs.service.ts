import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";

import { Job } from "./shared/models/jobs";
import jobs from "./jobs/jobs.json";
import { AngularFirestore } from "@angular/fire/compat/firestore";
import { MatSnackBar } from "@angular/material/snack-bar";

@Injectable({
  providedIn: "root",
})
export class JobsService {
  collection_companies: any = "jl_companies";
  collection_posting: any = "jl_posting";

  constructor(private fire: AngularFirestore,
              private snack: MatSnackBar) {}

  getJobs(): Observable<Job[]> {
    // TODO: replace this one with an actual call to a API or json-server
    return of(jobs);
  }

  getCompanies() {
    return this.fire.collection(this.collection_companies).valueChanges();
  }

  addPosting(data: any) {
    return this.fire.collection(this.collection_posting).doc().set(data);
  }

  getJobPosting() {
    return this.fire.collection(this.collection_posting).snapshotChanges();
  }

  getJobPost(id: any) {
    return this.fire.collection(this.collection_posting, ref => ref.where("id", "==", id)).snapshotChanges();
  }

  removeJobPost(id: any) {
    return this.fire
      .collection(this.collection_posting)
      .doc(id)
      .update({ delete: true });
  }

  snackBar(message: string, action: string) {
    this.snack.open(message, action);
  }
}
