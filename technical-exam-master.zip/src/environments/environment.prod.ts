export const environment = {
  production: true,
  apiKey: "AIzaSyDTqlfr_MLUjRsxUtMZv8Ro60Zf6jsMxKQ",
  authDomain: "jobs-listing-251c6.firebaseapp.com",
  projectId: "jobs-listing-251c6",
  storageBucket: "jobs-listing-251c6.appspot.com",
  messagingSenderId: "705725862500",
  appId: "1:705725862500:web:99038b6150b21ccda28571",
  measurementId: "G-SWHTN49D6Y",
};
